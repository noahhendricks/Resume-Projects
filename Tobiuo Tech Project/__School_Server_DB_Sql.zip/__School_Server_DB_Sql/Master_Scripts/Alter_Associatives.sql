/* MASTER ALTER SCRIPT FOR ASSOCIATIVE TABLES */
/*			TOBIUO TECHNOLOGIES			*/
/*		PLEASE VERIFY ALL DATA TYPES	*/


ALTER TABLE Belt_Exam_Registration
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID)
ALTER TABLE Belt_Exam_Registration
	ADD FOREIGN KEY (Exam_ID) REFERENCES Belt_Exam(Exam_ID)

ALTER TABLE Class_Registration
    ADD FOREIGN KEY (Class_ID) REFERENCES Class(Class_ID);
ALTER TABLE Class_Registration
    ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);

ALTER TABLE Employee_Covid_Check
    ADD FOREIGN KEY (Employee_ID) REFERENCES Employee(Employee_ID);
ALTER TABLE Employee_Covid_Check
    ADD FOREIGN KEY (COVID_Check_ID) REFERENCES COVID_Check(COVID_Check_ID);

ALTER TABLE Employee_Incident
	ADD FOREIGN KEY (Employee_ID) REFERENCES Employee (Employee_ID);
ALTER TABLE Employee_Incident
	ADD FOREIGN KEY (Incident_ID) REFERENCES Incident (Incident_ID);

ALTER TABLE Employee_Schedule
	ADD FOREIGN KEY (School_Location_ID) REFERENCES School_Location (School_Location_ID);
ALTER TABLE Employee_Schedule
	ADD FOREIGN KEY (Employee_ID) REFERENCES Employee (Employee_ID);
ALTER TABLE Employee_Schedule
	ADD FOREIGN KEY (Session_ID) REFERENCES Session_Meet (Session_ID);

ALTER TABLE Employee_School_Location
	ADD FOREIGN KEY (School_Location_ID) REFERENCES School_Location (School_Location_ID);
ALTER TABLE Employee_School_Location
	ADD FOREIGN KEY (Employee_ID) REFERENCES Employee (Employee_ID);

ALTER TABLE Location_Special_Event
	ADD FOREIGN KEY (School_Location_ID) REFERENCES School_Location(School_Location_ID);
ALTER TABLE Location_Special_Event
	ADD FOREIGN KEY (Special_Event_ID) REFERENCES Special_Event(Special_Event_ID);

ALTER TABLE Session_Incident
	ADD FOREIGN KEY (Session_ID) REFERENCES Session_Meet(Session_ID);
ALTER TABLE Session_Incident
	ADD FOREIGN KEY (Incident_ID) REFERENCES Incident(Incident_ID);

ALTER TABLE Session_Attendance
	ADD FOREIGN KEY (Session_ID) REFERENCES Session_Meet(Session_ID);
ALTER TABLE Session_Attendance
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);

ALTER TABLE Special_Event_Registration
	ADD FOREIGN KEY (Special_Event_ID) REFERENCES Special_Event(Special_Event_ID);
ALTER TABLE Special_Event_Registration
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);

ALTER TABLE Student_Appointment
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);
ALTER TABLE Student_Appointment
	ADD FOREIGN KEY (Appointment_ID) REFERENCES Appointment(Appointment_ID);

ALTER TABLE Student_Covid_Check
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);
ALTER TABLE Student_Covid_Check	
	ADD FOREIGN KEY (COVID_Check_ID) REFERENCES Covid_Check(COVID_Check_ID);

ALTER TABLE Student_Guardian
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);
ALTER TABLE Student_Guardian
	ADD FOREIGN KEY (Guardian_ID) REFERENCES Guardian(Guardian_ID);

ALTER TABLE Student_Incident
	ADD FOREIGN KEY (Incident_ID) REFERENCES Incident(Incident_ID);
ALTER TABLE Student_Incident
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);

ALTER TABLE Student_Medical_Problem
    ADD FOREIGN KEY (Medical_Problem_ID) REFERENCES Medical_Problem(Medical_Problem_ID);
ALTER TABLE Student_Medical_Problem
	ADD FOREIGN KEY (Medicine_ID)REFERENCES Medicine(Medicine_ID);
ALTER TABLE Student_Medical_Problem
    ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);