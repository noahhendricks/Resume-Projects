/* MASTER ALTER SCRIPT FOR Core TABLES */
/*			TOBIUO TECHNOLOGIES			*/
/*		PLEASE VERIFY ALL DATA TYPES	*/

ALTER TABLE Appointment
	ADD FOREIGN KEY (Appointment_Type_ID) REFERENCES Appointment_Type (Appointment_Type_ID);
ALTER TABLE Appointment
	ADD FOREIGN KEY (Appointment_Status_ID) REFERENCES Appointment_Status (Appointment_Status_ID);
ALTER TABLE Appointment
	ADD FOREIGN KEY (Employee_ID) REFERENCES Employee (Employee_ID);

ALTER TABLE Class
	ADD FOREIGN KEY (Class_Status_ID) REFERENCES Class_Status(Class_Status_ID);
ALTER TABLE Class
	ADD FOREIGN KEY (Course_ID) REFERENCES Course (Course_ID);

ALTER TABLE Course
	ADD FOREIGN KEY (Course_Status_ID) REFERENCES Course_Status (Course_Status_ID);

ALTER TABLE Employee
    ADD FOREIGN KEY (Country_ID) REFERENCES Country(Country_ID);
ALTER TABLE Employee
    ADD FOREIGN KEY (State_Territory_ID) REFERENCES State_Territory(State_Territory_ID);
ALTER TABLE Employee
    ADD FOREIGN KEY (Employee_Title_ID) REFERENCES Employee_Title(Employee_Title_ID);
ALTER TABLE Employee
    ADD FOREIGN KEY (Employee_Status_ID) REFERENCES Employee_Status(Employee_Status_ID);

ALTER TABLE Employee_Feedback
	ADD FOREIGN KEY (Employee_ID) REFERENCES Employee(Employee_ID);

ALTER TABLE Guardian
	ADD FOREIGN KEY (Guardian_Relationship_ID) REFERENCES Guardian_Relationship(Guardian_Relationship_ID);

ALTER TABLE Incident
	ADD FOREIGN KEY (Incident_Type_ID) REFERENCES Incident_Type (Incident_Type_ID);


ALTER TABLE Medical_Problem
    ADD FOREIGN KEY (Medicine_ID) REFERENCES Medicine(Medicine_ID);

ALTER TABLE Membership
	ADD FOREIGN KEY (Membership_Type_ID) REFERENCES Membership_Type(Membership_Type_ID);
ALTER TABLE Membership
	ADD FOREIGN KEY (Membership_Status_ID) REFERENCES Membership_Status(Membership_Status_ID);

ALTER TABLE Session_Meet
	ADD FOREIGN KEY (Session_Status_ID) REFERENCES Session_Status(Session_Status_ID);
ALTER TABLE Session_Meet
	ADD FOREIGN KEY (Class_ID) REFERENCES Class(Class_ID);

ALTER TABLE Special_Event
	ADD FOREIGN KEY (Special_Event_Type_ID) REFERENCES Special_Event_Type(Special_Event_Type_ID);
ALTER TABLE Special_Event
	ADD FOREIGN KEY (Special_Event_Status_ID) REFERENCES Special_Event_Status(Special_Event_Status_ID);

ALTER TABLE Special_Event_Feedback
	ADD FOREIGN KEY (Special_Event_ID) REFERENCES Special_Event(Special_Event_ID);

ALTER TABLE Student
	ADD FOREIGN KEY (Class_Rank_ID) REFERENCES Class_Rank(Class_Rank_ID);
ALTER TABLE Student
	ADD FOREIGN KEY (Country_ID) REFERENCES Country(Country_ID);
ALTER TABLE Student	
	ADD FOREIGN KEY (State_Territory_ID) REFERENCES State_Territory(State_Territory_ID);
ALTER TABLE Student
	ADD FOREIGN KEY (Stu_Status_ID) REFERENCES Student_Status(Stu_Status_ID);
ALTER TABLE Student
	ADD FOREIGN KEY (Membership_ID) REFERENCES Membership(Membership_ID);

ALTER TABLE Student_Feedback
	ADD FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID);