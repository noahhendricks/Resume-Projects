/* MASTER ALTER SCRIPT FOR LOOKUP TABLES */
/*			TOBIUO TECHNOLOGIES			*/
/*		PLEASE VERIFY ALL DATA TYPES	*/


ALTER TABLE School_Location
	ADD FOREIGN KEY (Country_ID) REFERENCES Country (Country_ID);
ALTER TABLE School_Location
	ADD FOREIGN KEY (State_Territory_ID) REFERENCES State_Territory (State_Territory_ID);
ALTER TABLE School_Location
	ADD FOREIGN KEY (School_Location_Status_ID) REFERENCES School_Location_Status (School_Location_Status_ID);

ALTER TABLE State_Territory
    ADD FOREIGN KEY (Country_ID) REFERENCES Country(Country_ID);

