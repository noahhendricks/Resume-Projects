/* MASTER CREATE SCRIPT FOR ASSOCIATIVE TABLES */
/*				TOBIUO TECHNOLOGIES			   */
/*			PLEASE VERIFY ALL DATA TYPES	   */
/*				  53 TABLES TOTAL			   */


CREATE TABLE Belt_Exam_Registration (
    Belt_Exam_Registration_ID int identity (1,1) NOT NULL,
    Fee_Paid varchar(10)NOT NULL,
	Pass_Fail varchar(10),
	Student_ID int NOT NULL,
	Exam_ID int NOT NULL,
    PRIMARY KEY (Belt_Exam_Registration_ID)
	);

CREATE TABLE Class_Registration (
	Class_Registration_ID int identity(1,1) NOT NULL,
	Class_Registration_Name varchar(75) NOT NULL,
	Class_ID int,
	Student_ID int,
	PRIMARY KEY (Class_Registration_ID)
);

CREATE TABLE Employee_Covid_Check (
	Employee_Covid_Check_ID int identity (1,1) NOT NULL,
	Employee_Covid_Check varchar(50) NOT NULL,
	Employee_ID int NOT NULL,
	COVID_Check_ID int NOT NULL,
	PRIMARY KEY (Employee_Covid_Check_ID)
	);

CREATE TABLE Employee_Incident (
	Employee_Incident_ID int identity (1,1) NOT NULL,
	Employee_Incident_Date DATE NOT NULL,
	Employee_ID int NOT NULL,
	Incident_ID int NOT NULL,
	PRIMARY KEY (Employee_Incident_ID) 
	);

CREATE TABLE Employee_Schedule (
	Empl_Sess_ID int identity (1,1) NOT NULL,
	Empl_Sess_Date DATE NOT NULL,
	School_Location_ID int NOT NULL,
	Employee_ID int NOT NULL,
	Session_ID int NOT NULL,
	PRIMARY KEY (Empl_Sess_ID) 
	);

CREATE TABLE Employee_School_Location (
	EMPL_Location_ID int identity (1,1) NOT NULL,
	EMPL_Location_Name VARCHAR (75) NOT NULL,
	School_Location_ID int NOT NULL,
	Employee_ID int NOT NULL,
	PRIMARY KEY (EMPL_Location_ID) 
	);

CREATE TABLE Location_Special_Event (
    Location_Special_Event_ID int identity (1,1) NOT NULL,
    Location_Special_Event_Info text NOT NULL,
    School_Location_ID int NOT NULL,
    Special_Event_ID int NOT NULL,
    PRIMARY KEY (Location_Special_Event_ID)
    );

CREATE TABLE Session_Attendance (
    Sess_Attendance_ID int IDENTITY(1,1) NOT NULL,
    Sess_Attendance_Date date NOT NULL,
    Sess_Attendance_Status varchar(10) NOT NULL,
    Session_ID int NOT NULL,
    Student_ID int NOT NULL,
    PRIMARY KEY (Sess_Attendance_ID),
    );

CREATE TABLE Session_Incident (
    Session_Incident_ID int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Session_Incident_Date date NOT NULL,
    Session_ID int NOT NULL,
    Incident_ID int NOT NULL,
    );

CREATE TABLE Special_Event_Registration (
	Special_Event_Registration_ID int identity(1,1) NOT NULL PRIMARY KEY,
	Special_Event_Time varchar(10) NOT NULL,
	Special_Event_Date date NOT NULL,
	Special_Event_ID int NOT NULL,
	Student_ID int NOT NULL,
	);

CREATE TABLE Student_Appointment (
	Student_Appointment_ID int identity(1,1) NOT NULL,
	Student_Appointment_Date date NOT NULL,
	Student_ID int NOT NULL,
	Appointment_ID int NOT NULL,
	PRIMARY KEY (Student_Appointment_ID)
);

CREATE TABLE Student_Covid_Check (
    Student_Covid_Check_ID int identity(1, 1) NOT NULL,
    Student_Covid_Check varchar(10)  CHECK(Student_Covid_Check IN('y','n')),
	Student_ID int NOT NULL,
	COVID_Check_ID int NOT NULL,
	PRIMARY KEY (Student_Covid_Check_ID),
    );

CREATE TABLE Student_Guardian (
	Student_Guardian_ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Student_Guardian_Required VARCHAR(5) NOT NULL,
	Student_ID int NOT NULL, 
	Guardian_ID int NULL,
	);

CREATE TABLE Student_Incident (
    Student_Incident_ID int identity(1, 1) NOT NULL,
	Student_Incident_Date date NOT NULL,
	Incident_ID int NOT NULL,
	Student_ID int NOT NULL,
	PRIMARY KEY (Student_Incident_ID)
    );

CREATE TABLE Student_Medical_Problem (
	Student_Medical_Problem_ID int identity (1,1) NOT NULL PRIMARY KEY,
	Student_Medical_Problem_Exists Varchar(5) NOT NULL,
	Student_On_Medicine varchar(5) NOT NULL,
	Medical_Problem_ID int NULL,
	Medicine_ID int NULL,
	Student_ID int NOT NULL,
	);



Select * From Belt_Exam_Registration;
Drop Table Belt_Exam_Registration;


Select * From Class_Registration;
Drop Table Class_Registration;


Select * From Employee_Covid_Check;
Drop Table Employee_Covid_Check;


Select * From Employee_Incident;
Drop Table Employee_Incident;


Select * From Employee_Schedule;
Drop Table Employee_Schedule;


Select * From Employee_School_Location;
Drop Table Employee_School_Location;


Select * From Location_Special_Event;
Drop Table Location_Special_Event;


Select * From Session_Attendance;
Drop Table Session_Attendance;


Select * From Session_Incident;
Drop Table Session_Incident;


Select * From Special_Event_Registration;
Drop Table Special_Event_Registration;


Select * From Student_Appointment;
Drop Table Student_Appointment;


Select * From Student_Covid_Check;
Drop Table Student_Covid_Check;


Select * From Student_Guardian;
Drop Table Student_Guardian;


Select * From Student_Incident;
Drop Table Student_Incident;


Select * From Student_Medical_Problem;
Drop Table Student_Medical_Problem;