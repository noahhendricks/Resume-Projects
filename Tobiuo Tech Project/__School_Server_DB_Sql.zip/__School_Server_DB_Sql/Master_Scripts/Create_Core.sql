/* MASTER CREATE SCRIPT FOR CORE TABLES */
/*			TOBIUO TECHNOLOGIES			*/
/*		PLEASE VERIFY ALL DATA TYPES	*/

CREATE TABLE Appointment (
	Appointment_ID int identity(1,1) NOT NULL,
	Appointment_Date date NOT NULL,
	Appointment_Time varchar(10) NOT NULL,
	Appointment_Type_ID int NOT NULL,
	Appointment_Status_ID int NOT NULL,
	Employee_ID int NOT NULL,
	PRIMARY KEY (Appointment_ID),
	); 


CREATE TABLE Class(
	Class_ID INT IDENTITY(1, 1) NOT NULL,
	Class_Type varchar(75) NOT NULL,
	Class_Status_ID int NOT NULL,
	Class_Days varchar(75) NOT NULL,
	Class_Length varchar(12) NOT NULL,
	Course_ID int NOT NULL,
	PRIMARY KEY (Class_ID)
	);


CREATE TABLE Course(
	Course_ID INT IDENTITY (1, 1) NOT NULL,
	Course_Name Varchar(50) NOT NULL,
	Course_Information Varchar(150) NOT NULL,
	Course_Status_ID int,
	PRIMARY KEY (Course_ID)
	);


CREATE TABLE COVID_Check(
	COVID_Check_ID int identity (1,1) NOT NULL,
	COVID_Check_Date date NOT NULL,
	COVID_Check_Time Varchar(10) NOT NULL,
	Temperature decimal(4) NOT NULL,
	Exposure_Date date,
	COVID_Check_FirstName Varchar(100) NOT NULL,
	COVID_Check_LastName Varchar(100) NOT NULL,
	COVID_Check_PhoneNumber varchar(15) NOT NULL,
	PRIMARY KEY (COVID_Check_ID)
	);


CREATE TABLE Employee(
	Employee_ID int identity (1,1) NOT NULL,
	Employee_FirstName Varchar(100) NOT NULL,
	Employee_LastName Varchar(100) NOT NULL,
	Employee_Gender Varchar(10),
	Employee_Phone varchar(15) NOT NULL,
	Employee_Email varchar (255) NOT NULL,
	Employee_Street varchar (75),
	Employee_City Varchar(25) NOT NULL,
	Employee_Zipcode varchar (12) NOT NULL,
	Employee_StartDate date NOT NULL,
	Employee_EndDate date,
	Country_ID int NOT NULL,
	State_Territory_ID int NOT NULL,
	Employee_Title_ID int NOT NULL,
	Employee_Status_ID int NOT NULL,
	PRIMARY KEY (Employee_ID)
	);


CREATE TABLE Employee_Feedback(
	Employee_Feedback_ID int identity (1,1) NOT NULL,
	Employee_Rating	VARCHAR(50) NULL,
	Employee_Comment TEXT NOT NULL,
	Employee_ID int NULL,
	PRIMARY KEY (Employee_Feedback_ID) 
	);


CREATE TABLE Guardian(
	Guardian_ID int identity (1,1) NOT NULL,
	Guardian_FirstName VARCHAR(75)NOT NULL,
	Guardian_LastName VARCHAR(75)NOT NULL,
	Guardian_Phone Varchar(100) NOT NULL,
	Guardian_Email Varchar(65)NOT NULL,
	Guardian_Street Varchar(75)NOT NULL,
	Guardian_City VARCHAR(50)NOT NULL,
	Guardian_Zipcode Varchar(12)NOT NULL,
	Guardian_Relationship_ID int NOT NULL,
	PRIMARY KEY (Guardian_ID)
	);


CREATE TABLE Incident ( 
    Incident_ID int IDENTITY(1, 1) NOT NULL,
	Incident_Description Text NOT NULL,
	Incident_Type_ID int NOT NULL,
	PRIMARY KEY (Incident_ID)
	);


CREATE TABLE Medical_Problem(
	Medical_Problem_ID int identity (1,1) NOT NULL PRIMARY KEY,
	Medical_Problem_Name VARCHAR(75) NOT NULL,
	Medicine_ID int NOT NULL,
	);


CREATE TABLE Medicine ( 
    Medicine_ID int IDENTITY (1, 1) NOT NULL PRIMARY KEY,
	Medicine_Name VARCHAR(75) NOT NULL,
	Medicine_Reason VARCHAR(255) NOT NULL,
	);


CREATE TABLE Membership(
    Membership_ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
	Membership_StartDate DATE NOT NULL,
	Membership_EndDate DATE NOT NULL,
	Membership_Type_ID INT NOT NULL,
	Membership_Status_ID INT NOT NULL,
	);


CREATE TABLE Session_Meet (
    Session_ID int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Session_Day varchar(15) NOT NULL,
    Session_Start_Time varchar(10) NOT NULL,
    Session_End_Time varchar(10) NOT NULL,
    Session_Status_ID int NOT NULL,
	Class_ID int NOT NULL,
    );


CREATE TABLE Special_Event(
	Special_Event_ID int identity(1,1) NOT NULL PRIMARY KEY,
	Special_Event_Date date NOT NULL,
	Special_Event_Name Text,
	Special_Event_Type_ID int ,
	Special_Event_Status_ID int,
	);


CREATE TABLE Special_Event_Feedback(
    Special_Event_Feedback_ID INT IDENTITY (1,1) NOT NULL,
	Special_Event_Feedback_Rating VARCHAR(10) NOT NULL,
	Special_Event_Feedback_Comment text NOT NULL,
	Special_Event_ID int,
	PRIMARY KEY (Special_Event_Feedback_ID)
	);


CREATE TABLE Student (
    Student_ID int identity(1,1) PRIMARY KEY NOT NULL,
	Student_FirstName varchar (75) NOT NULL,
	Student_LastName varchar (75) NOT NULL,
	Student_Gender varchar(25),
	Student_DOB date NOT NULL,
	Student_Age int NOT NULL,
	Student_Phone varchar(15),
	Student_EmContName varchar(100) NOT NULL,
	Student_EmContNum varchar(15),
	Student_Email varchar(255) NOT NULL,
	Student_Street varchar(75),
	Student_City Varchar(50) NOT NULL,
	Student_Zipcode varchar(10) NOT NULL,
	Class_Rank_ID int NOT NULL,
	Country_ID int NOT NULL,
	State_Territory_ID int NOT NULL,
	Stu_Status_ID int NOT NULL,
	Membership_ID int NOT NULL,
	);


CREATE TABLE Student_Feedback(
	Student_Feedback_ID	int identity(1,1) NOT NULL, 
	Student_Feedback_Rating	VARCHAR(10) NULL,
	Student_Feedback_Comment TEXT NULL,
	Student_ID int NOT NULL 
	PRIMARY KEY (Student_Feedback_ID) 
	);




Select * From Appointment;
Drop Table Appointment;


Select * From Class;
Drop Table Class;


Select * From Course;
Drop Table Course;


Select * From COVID_Check;
Drop Table COVID_Check;


Select * From Employee;
Drop Table Employee;


Select * From Employee_Feedback;
Drop Table Employee_Feedback;


Select * from Guardian;
Drop Table Guardian;


Select * from Incident;
Drop Table Incident;


Select * from Medical_Problem;
Drop Table Medical_Problem;


Select * from Medicine;
Drop Table Medicine;


Select * from Membership;
Drop Table Membership;


Select * from Session_Meet;
Drop Table Session_Meet;


Select * from Special_Event;
Drop Table Special_Event;


Select * from Special_Event_Feedback;
Drop Table Special_Event_Feedback;


Select * from Student;
Drop Table Student;


Select * from Student_Feedback;
Drop TABLE Student_Feedback;