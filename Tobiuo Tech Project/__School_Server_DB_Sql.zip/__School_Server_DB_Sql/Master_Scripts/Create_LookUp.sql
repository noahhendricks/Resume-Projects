/* MASTER CREATE SCRIPT FOR LOOKUP TABLES */
/*			TOBIUO TECHNOLOGIES			*/
/*		PLEASE VERIFY ALL DATA TYPES	*/

CREATE TABLE Appointment_Status ( 
    Appointment_Status_ID INT IDENTITY (1,1) NOT NULL,
	Appointment_Status_Description varchar (25) NOT NULL,
	PRIMARY KEY (Appointment_Status_ID),
	);

CREATE TABLE Appointment_Type (
    Appointment_Type_ID int identity (1,1) NOT NULL,
    Appointment_Type_Description varchar (75) NOT NULL,
    PRIMARY KEY (Appointment_Type_ID)
    );

CREATE TABLE Belt_Exam (
    Exam_ID int identity (1,1) NOT NULL,
    Exam_Date date NOT NULL,
    Exam_Section varchar (45) NOT NULL,
    Section_Time varchar (10) NOT NULL,
    PRIMARY KEY (Exam_ID)
	);

CREATE TABLE Class_Rank (
	Class_Rank_ID int identity (1,1) NOT NULL,
	Class_Rank_Type varchar (50) NOT NULL,
	PRIMARY KEY (Class_Rank_ID)
	);

CREATE TABLE Class_Status (
    Class_Status_ID int identity (1,1) NOT NULL,
	Class_Status_Type varchar (50) NOT NULL,
	PRIMARY KEY (Class_Status_ID),
	);

CREATE TABLE Course_Status(
	Course_Status_ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Course_Status_Type varchar (15) NOT NULL,
	);

CREATE TABLE Country(
	Country_ID int identity (1,1) NOT NULL PRIMARY KEY,
	Country_Name varchar (45) NOT NULL,
	Country_Abbreviation varchar (10) NOT NULL
	);

CREATE TABLE Employee_Status(
	Employee_Status_ID int identity (1,1) NOT NULL,
	Employee_Status varchar (15) NOT NULL,
	PRIMARY KEY (Employee_Status_ID)
	);

CREATE TABLE Employee_Title(
	Employee_Title_ID int identity (1,1) NOT NULL,
	Employee_Title_Type varchar (20) NOT NULL,
	PRIMARY KEY (Employee_Title_ID)
	);

CREATE TABLE Guardian_Relationship (
    Guardian_Relationship_ID int IDENTITY (1,1) NOT NULL,
    Guardian_Relationship_Type varchar (30) NOT NULL,
    PRIMARY KEY (Guardian_Relationship_ID)
    );

CREATE TABLE Incident_Type (
	Incident_Type_ID int identity(1,1) NOT NULL,
	Incident_Type_Description Text NOT NULL,
	PRIMARY KEY (Incident_Type_ID)
	);


CREATE TABLE Membership_Status (
	Membership_Status_ID int identity(1,1) NOT NULL PRIMARY KEY,
	Membership_Status_Type VARCHAR(10) NOT NULL,  
	);

CREATE TABLE Membership_Type (
	Membership_Type_ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Membership_Name varchar (75) NOT NULL,
	Membership_Description varchar (255) NOT NULL,
	Membership_Fee varchar (55) NOT NULL,
	);

CREATE TABLE School_Location (
	School_Location_ID int IDENTITY (1,1) PRIMARY KEY NOT NULL,
	School_Location_Name Text NOT NULL,
	School_Location_Street varchar (75) NOT NULL,
	School_Location_City varchar (75) NOT NULL,
	School_Location_State varchar (75) NOT NULL,
	School_Location_Zipcode varchar(10) NOT NULL,
	School_Location_Phone varchar(20) NOT NULL,
	School_Location_Email varchar(255) NOT NULL,
	Country_ID int,
	State_Territory_ID int,
	School_Location_Status_ID int,
	);

CREATE TABLE School_Location_Status ( 
    School_Location_Status_ID int identity (1,1) NOT NULL, 
	School_Location_Status_Type varchar (10) NOT NULL,
	PRIMARY KEY (School_Location_Status_ID),
	);

CREATE TABLE Session_Status (
    Session_Status_ID int IDENTITY(1,1) NOT NULL,
    Session_Status_Type varchar (15) NOT NULL,
    PRIMARY KEY (Session_Status_ID)
    );

CREATE TABLE Special_Event_Status (
	Special_Event_Status_ID int identity(1,1) NOT NULL,
	Special_Event_Status_Type varchar (15) NOT NULL,
	PRIMARY KEY (Special_Event_Status_ID)	
	);

CREATE TABLE Special_Event_Type (
	Special_Event_Type_ID int identity (1,1) NOT NULL PRIMARY KEY,
	Special_Event_Type_Name varchar (75) NOT NULL
	);

CREATE TABLE State_Territory (
	State_Territory_ID int identity (1,1) NOT NULL PRIMARY KEY,
	State_Territory_Name VARCHAR (200) NOT NULL,
	State_Territory_Abbreviation VARCHAR (10) NOT NULL,
	Country_ID int,
	Zip_Code VARCHAR (15) NOT NULL,
	);

CREATE TABLE Student_Status (
    Stu_Status_ID int identity(1, 1) NOT NULL,
	Student_Status varchar (10) NOT NULL,
	PRIMARY KEY (Stu_Status_ID)
    );



Select * From Appointment_Status;
Drop Table Appointment_Status;

Select * From Appointment_Type;
Drop Table Appointment_Type;


Select * From Belt_Exam;
Drop Table Belt_Exam;


Select * From Class_Rank;
Drop Table Class_Rank;


Select * From Class_Status;
Drop Table Class_Status;


Select * From Course_Status;
Drop Table Course_Status;


Select * from Country;
Drop Table Country;


Select * from Employee_Status;
Drop Table Employee_Status;


Select * from Employee_Title;
Drop Table Employee_Title;


Select * from Guardian_Relationship;
Drop Table Guardian_Relationship;


Select * from Incident_Type;
Drop Table Incident_Type;


Select * from Membership_Status;
Drop Table Membership_Status;


Select * from Membership_Type;
Drop Table Membership_Type;


Select * from School_Location;
Drop Table School_Location;


Select * from School_Location_Status;
Drop TABLE School_Location_Status;


Select * from Session_Status;
Drop Table Session_Status;


Select * from Special_Event_Status;
Drop Table Special_Event_Status;


Select * from Special_Event_Type;
Drop Table Special_Event_Type;


Select * from State_Territory;
Drop Table State_Territory;


Select * from Student_Status;
Drop TABLE Student_Status;

