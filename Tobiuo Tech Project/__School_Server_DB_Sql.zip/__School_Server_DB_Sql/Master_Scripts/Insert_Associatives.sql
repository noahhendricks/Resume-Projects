/* MASTER BULK INSERT SCRIPT FOR Associative TABLES */
/*			TOBIUO TECHNOLOGIES				 */
/*		PLEASE VERIFY ALL DATA TYPES	     */
/*		DOWNLOAD ALL CSV DATA TO INSERT	     */

BULK INSERT Student_Appointment
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student_Appointment.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
	)

BULK INSERT Class_Registration
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Class_Registration.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Belt_Exam_Registration
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Belt_Exam_Registration.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Student_Guardian
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student_Guardian.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Session_Attendance
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Session_Attendance.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Employee_Schedule
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_Schedule.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Employee_School_Location
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_School_Location.txt'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Employee_Covid_Check
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_Covid_Check.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Location_Special_Event
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Location_Special_Event.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Special_Event_Registration
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Special_Event_Registration.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Session_Incident
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Session_Incident.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Student_Incident
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student_Incident.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Student_Medical_Problem
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student Medical Problem.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Student_Covid_Check
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student_Covid_Check.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Employee_Incident
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_Incident.txt'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)