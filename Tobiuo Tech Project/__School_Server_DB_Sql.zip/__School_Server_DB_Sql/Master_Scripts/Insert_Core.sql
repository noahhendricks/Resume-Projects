/* MASTER BULK INSERT SCRIPT FOR CORE TABLES */
/*			TOBIUO TECHNOLOGIES				 */
/*		PLEASE VERIFY ALL DATA TYPES	     */
/*		DOWNLOAD ALL CSV DATA TO INSERT	     */

BULK INSERT Appointment
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Appointment.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
	)

BULK INSERT Class
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Class.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Course
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Course.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	LASTROW = 11,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT COVID_Check
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\COVID_Check.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Employee
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Employee_Feedback
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_Feedback.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Guardian
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Guardian.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Incident
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Incident.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Medical_Problem
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Medical Problem.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Medicine
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Medicine.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Membership
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Membership.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Session_Meet
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Session_Meet.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Special_Event
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Special_Event.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Special_Event_Feedback
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Special_Event_Feedback.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Student
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Student_Feedback
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student_Feedback.txt'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)
