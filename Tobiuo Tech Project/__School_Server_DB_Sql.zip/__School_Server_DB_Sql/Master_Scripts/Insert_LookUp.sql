/* MASTER BULK INSERT SCRIPT FOR LookUp TABLES */
/*			TOBIUO TECHNOLOGIES				 */
/*		PLEASE VERIFY ALL DATA TYPES	     */
/*		DOWNLOAD ALL CSV DATA TO INSERT	     */

BULK INSERT Appointment_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Appointment_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Appointment_Type
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Appointment_Type.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Belt_Exam
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Belt_Exam.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Class_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Class_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Class_Rank
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Class_Rank.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Course_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Course_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Country
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Country.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Employee_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Employee_Title
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Employee_Title.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Guardian_Relationship
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Guardian_Relationship.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Incident_Type
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Incident_Type.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Membership_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Membership_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Membership_Type
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Membership_Type.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT School_Location
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\School_Location.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT School_Location_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\School_Location_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Session_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Session_Status.csv'
WITH (
    DATAFILETYPE = 'char',
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT Special_Event_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Special_Event_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Special_Event_Type
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Special_Event_Type.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT State_Territory
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\State_Territory.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW =2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

BULK INSERT Student_Status
FROM 'C:\__Master_Scripts__\Tobiuo Tech\Master_Scripts\DATA TABLES\Student_Status.csv'
WITH (
	DATAFILETYPE = 'char',
	FIRSTROW = 2,
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)
